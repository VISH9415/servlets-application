package com.capgemini.service;

import com.capgemini.bean.BillingBean;
import com.capgemini.bean.ConsumerBean;
import com.capgemini.dao.BillDAOImpl;
import com.capgemini.exception.BillingException;

public class BillServiceImpl implements IBillService{
    BillDAOImpl billDAO = new BillDAOImpl();
	@Override
	public int insertBillDetails(BillingBean billingBean) throws BillingException {
		// TODO Auto-generated method stub
		return billDAO.insertBillDetails(billingBean);
	}
	@Override
	public ConsumerBean selectConsumerDetails(String conNo) throws BillingException{
		// TODO Auto-generated method stub
		return billDAO.selectConsumerDetails(conNo);
	}
	
}
