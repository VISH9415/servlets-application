package com.capgemini.utility;

import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.*;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class DBUtil {
	private static Connection con = null;
  public static Connection createConnection() {
	  
	  try{
	  InitialContext context = new InitialContext();
	  DataSource ds = (DataSource) context.lookup("java:/jdbc/OracleDS");
	  con=ds.getConnection();
	  }catch(NamingException e){
		  e.printStackTrace();
	  }catch(SQLException e){
		  e.printStackTrace();
	  }
	  return con;
  }
  
  public static void closeConnection() throws SQLException{
	  if(con != null){
		  con.close();
	  }
  }


  }
  
