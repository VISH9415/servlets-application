package com.capgemini.bean;

import java.time.LocalDate;

public class BillingBean {
	
private int billNumber;
private double currentReading;
private double unitsConsumed;
private double netAmount;
private LocalDate billDate;
private String consumerNumber;
private String consumerName;
private String address;

public BillingBean() {
	super();
}



public BillingBean(int billNumber, double currentReading, double unitsConsumed,
		double netAmount, LocalDate billDate, String consumerNumber,
		String consumerName, String address) {
	super();
	this.billNumber = billNumber;
	this.currentReading = currentReading;
	this.unitsConsumed = unitsConsumed;
	this.netAmount = netAmount;
	this.billDate = billDate;
	this.consumerNumber = consumerNumber;
	this.consumerName = consumerName;
	this.address = address;
}



public int getBillNumber() {
	return billNumber;
}

public void setBillNumber(int billNumber) {
	this.billNumber = billNumber;
}

public double getCurrentReading() {
	return currentReading;
}

public void setCurrentReading(double currentReading) {
	this.currentReading = currentReading;
}

public double getUnitsConsumed() {
	return unitsConsumed;
}

public void setUnitsConsumed(double unitsConsumed) {
	this.unitsConsumed = unitsConsumed;
}

public double getNetAmount() {
	return netAmount;
}

public void setNetAmount(double netAmount) {
	this.netAmount = netAmount;
}

public LocalDate getBillDate() {
	return billDate;
}

public void setBillDate(LocalDate billDate) {
	this.billDate = billDate;
}

public String getConsumerNumber() {
	return consumerNumber;
}

public void setConsumerNumber(String consumerNumber) {
	this.consumerNumber = consumerNumber;
}

public String getConsumerName() {
	return consumerName;
}

public void setConsumerName(String consumerName) {
	this.consumerName = consumerName;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}




}
