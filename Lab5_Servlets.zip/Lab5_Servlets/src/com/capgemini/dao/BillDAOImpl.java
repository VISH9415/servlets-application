package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.bean.BillingBean;
import com.capgemini.bean.ConsumerBean;
import com.capgemini.exception.BillingException;
import com.capgemini.utility.DBUtil;

public class BillDAOImpl implements IBillDAO{

	@Override
	public int insertBillDetails(BillingBean billingBean) throws BillingException {
		// TODO Auto-generated method stub
		int status = 0;
		Connection con =null;
		PreparedStatement pst= null;
		String sql = new String("INSERT INTO billdetails(bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_Date)VALUES(seq_bill_num.nextval,?,?,?,?,sysdate)");
		try{
		con = DBUtil.createConnection();
		pst = con.prepareStatement(sql);
		pst.setInt(1,Integer.parseInt(billingBean.getConsumerNumber()));
		pst.setDouble(2,billingBean.getCurrentReading());
		pst.setDouble(3,billingBean.getUnitsConsumed());
		pst.setDouble(4,billingBean.getNetAmount());
	    status = pst.executeUpdate();
		/*if(status==1)
		{
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select seq_bill_num.currval from dual");
		  if(rs.next())
		  {
			  return rs.getInt(1);
		  }
		}
		*/
		}
	    catch(SQLException se)
		{
				throw new BillingException(se.getMessage());
		}
		return status;
}
		
	@Override
  public ConsumerBean selectConsumerDetails(String conNo) throws BillingException {
  ConsumerBean consumerBean = new ConsumerBean();
  Connection con = DBUtil.createConnection();
  String query = "select * from consumers where consumer_num=?";
		// TODO Auto-generated method stub
		try
  {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1,Integer.parseInt(conNo));
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				consumerBean.setConsumerNo(rs.getString(1));
				consumerBean.setConsumerName(rs.getString(2));
				consumerBean.setAddress(rs.getString(3));
			}
  }catch(SQLException e){
	  throw new BillingException(e.getMessage());
  }
		return consumerBean;
	}



}
