package com.capgemini.dao;

import com.capgemini.bean.BillingBean;
import com.capgemini.bean.ConsumerBean;
import com.capgemini.exception.BillingException;

public interface IBillDAO {

	int insertBillDetails(BillingBean billingBean) throws BillingException;
	public ConsumerBean selectConsumerDetails(String conNo) throws BillingException;
	
}
