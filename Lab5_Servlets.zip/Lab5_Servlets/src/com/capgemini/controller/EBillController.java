package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.bean.BillingBean;
import com.capgemini.bean.ConsumerBean;
import com.capgemini.exception.BillingException;
import com.capgemini.service.BillServiceImpl;

/**
 * Servlet implementation class EBillController
 */
@WebServlet("/EBillController")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	BillServiceImpl billService = new BillServiceImpl();
    public EBillController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		BillingBean billingBean = new BillingBean();
		ConsumerBean consumerBean = new ConsumerBean();
		//String path= request.getQueryString();
		String action = request.getParameter("action");
		switch(action){
		case "1":
		String connum = request.getParameter("cnumber");
		String lastmon = request.getParameter("lmonread"); 
		String currmon = request.getParameter("cmonread");
		double units = Double.parseDouble(currmon)-Double.parseDouble(lastmon);
		double fixed = 100;
		double amt = units*1.5 + fixed;
		billingBean.setConsumerNumber(connum);
		//consumerBean.setConsumerNo(connum);
		billingBean.setCurrentReading(Double.parseDouble(currmon));
		billingBean.setUnitsConsumed(units);
		billingBean.setNetAmount(amt);
		PrintWriter out= response.getWriter();
		try{
			int status = billService.insertBillDetails(billingBean);
			consumerBean = billService.selectConsumerDetails(connum);
			request.setAttribute("Bill",billingBean);
			request.setAttribute("consumer",consumerBean);
			//out.println(status);
			RequestDispatcher rd = request.getRequestDispatcher("PrintBill.jsp");
			rd.forward(request,response);
		}catch(BillingException e){
			request.setAttribute("Error", e.getMessage());
			request.setAttribute("cnum",connum);
			//request.setAttribute("Bill",billingBean);
			//request.setAttribute("consumer",consumerBean);
			RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
			rd.forward(request, response);
		}
		case "2":
			break;
		}

}
	}
